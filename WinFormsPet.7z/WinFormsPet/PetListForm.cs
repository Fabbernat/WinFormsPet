﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsPet.Controllers;

namespace WinFormsPet
{
    public partial class PetListForm : Form
    {
        private PetController petController = new PetController();

        public PetListForm()
        {
            InitializeComponent();
            LoadPets();
        }

        private void LoadPets()
        {
            var pets = petController.GetPets();
            petGridView.DataSource = pets; // Assuming DataGridView
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var addForm = new PetForm();
            addForm.ShowDialog();
            LoadPets(); // Refresh list
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
