﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;

namespace WinFormsPet
{
    public class Database
    {
        private static string dbFile = "PetRegistry.db";
        private static string connectionString = $"Data Source={dbFile};Version=3;";

        public static SqliteConnection GetConnection()
        {
            if (!File.Exists(dbFile))
            {
                SQLiteConnection.CreateFile(dbFile);
                InitializeDatabase();
            }
            return new SQLiteConnection(connectionString);
        }

        private static void InitializeDatabase()
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                var sql = @"
                CREATE TABLE IF NOT EXISTS Pets (
                    Id TEXT PRIMARY KEY, 
                    Name TEXT, 
                    Species TEXT, 
                    Breed TEXT, 
                    Age INTEGER, 
                    OwnerId TEXT
                );
                CREATE TABLE IF NOT EXISTS Owners (
                    Id TEXT PRIMARY KEY, 
                    Name TEXT, 
                    ContactNumber TEXT, 
                    Address TEXT
                );
            ";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
