﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsPet.Models;

namespace WinFormsPet.Controllers
{



    public class PetController
    {
        public void AddPet(Pet pet)
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                string sql = "INSERT INTO Pets (Id, Name, Species, Breed, Age, OwnerId) VALUES (@Id, @Name, @Species, @Breed, @Age, @OwnerId)";
                conn.Execute(sql, pet);
            }
        }

        public List<Pet> GetPets()
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                return conn.Query<Pet>("SELECT * FROM Pets").AsList();
            }
        }

        public void UpdatePet(Pet pet)
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                string sql = "UPDATE Pets SET Name=@Name, Species=@Species, Breed=@Breed, Age=@Age WHERE Id=@Id";
                conn.Execute(sql, pet);
            }
        }

        public void DeletePet(string petId)
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                conn.Execute("DELETE FROM Pets WHERE Id=@Id", new { Id = petId });
            }
        }
    }
}