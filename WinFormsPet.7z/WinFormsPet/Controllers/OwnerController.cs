﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using WinFormsPet.Models;

namespace WinFormsPet.Controllers
{
    public class OwnerController
    {
        public void AddOwner(Owner owner)
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                string sql = "INSERT INTO Owners (Id, Name, ContactNumber, Address) VALUES (@Id, @Name, @ContactNumber, @Address)";
                conn.Execute(sql, owner);
            }
        }

        public List<Owner> GetOwners()
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                return conn.Query<Owner>("SELECT * FROM Owners").AsList();
            }
        }

        public void UpdateOwner(Owner owner)
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                string sql = "UPDATE Owners SET Name=@Name, ContactNumber=@ContactNumber, Address=@Address WHERE Id=@Id";
                conn.Execute(sql, owner);
            }
        }

        public void DeleteOwner(string ownerId)
        {
            using (var conn = Database.GetConnection())
            {
                conn.Open();
                conn.Execute("DELETE FROM Owners WHERE Id=@Id", new { Id = ownerId });
            }
        }
    }

}
