﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsPet
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            btnPets.Click += (s, e) => new PetListForm().Show();
            btnOwners.Click += (s, e) => new OwnerListForm().Show();
            btnSettings.Click += (s, e) => new SettingsForm().Show();
            btnPrivacy.Click += (s, e) => new PrivacyForm().Show();
        }
    }
}
